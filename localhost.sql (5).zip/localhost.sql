-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 15, 2016 at 03:40 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `kwikmedical`
--
CREATE DATABASE `kwikmedical` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `kwikmedical`;

-- --------------------------------------------------------

--
-- Table structure for table `call_out_information`
--

CREATE TABLE IF NOT EXISTS `call_out_information` (
  `CallOutId` int(11) NOT NULL AUTO_INCREMENT,
  `PatientID` int(11) NOT NULL,
  `What` varchar(200) NOT NULL,
  `When` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `Where` varchar(50) NOT NULL,
  `ActionTaken` varchar(200) NOT NULL,
  `TimeSpentOnCall` time NOT NULL,
  PRIMARY KEY (`CallOutId`),
  KEY `PatientID` (`PatientID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `call_out_information`
--

INSERT INTO `call_out_information` (`CallOutId`, `PatientID`, `What`, `When`, `Where`, `ActionTaken`, `TimeSpentOnCall`) VALUES
(11, 1000, 'Broken Leg', '2016-11-15 13:58:07', 'Edinburgh', 'Xrayed', '00:35:26'),
(13, 1001, 'Broken arm', '2016-11-15 14:54:14', 'Patients work', 'arm covered and taken to hospital for further examination', '00:56:12'),
(14, 1004, 'Asthma Attack', '2016-11-15 15:12:22', 'Albert Street, Edinburgh', 'gave the patient oxygen mask to try control breathing. brought to hospital for further examination', '01:54:23');

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE IF NOT EXISTS `patients` (
  `NHSRegistrationNumber` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  `HouseNameOrNumber` varchar(50) NOT NULL,
  `Street` varchar(50) NOT NULL,
  `CityOrTown` varchar(50) NOT NULL,
  `Postcode` varchar(9) NOT NULL,
  `MedicalCondition` varchar(500) NOT NULL,
  PRIMARY KEY (`NHSRegistrationNumber`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1005 ;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`NHSRegistrationNumber`, `Name`, `HouseNameOrNumber`, `Street`, `CityOrTown`, `Postcode`, `MedicalCondition`) VALUES
(1000, 'David Dryburgh', '12', 'Rope Walk', 'Prestonpans', 'EH32 9BN', 'Asthma'),
(1001, 'John Smith', '34', 'Lothian Road', 'Edinburgh', 'EH11 9LJ', 'Broken Arm'),
(1002, 'Bob Doe', 'Colin House', 'Colinton Road', 'Edinburgh', 'EH12 9BN', 'Heart Conditions'),
(1003, 'Murray Black', '55', 'Hope Road', 'Edinburgh', 'EH43 6KG', 'Broken Arm'),
(1004, 'Brian Smith', '25', 'Albert Street', 'Edinburgh', 'EH8 9BN', 'Asthma');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `call_out_information`
--
ALTER TABLE `call_out_information`
  ADD CONSTRAINT `call_out_information_ibfk_1` FOREIGN KEY (`PatientID`) REFERENCES `patients` (`NHSRegistrationNumber`) ON DELETE CASCADE ON UPDATE CASCADE;
