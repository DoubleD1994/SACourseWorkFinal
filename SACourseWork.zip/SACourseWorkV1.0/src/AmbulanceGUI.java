import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

public class AmbulanceGUI 
{
	// First set up the panel with the labels and text boxes
	private JPanel inputPanel = new JPanel();
	private JLabel whoLabel = new JLabel("NHS Number: ");
	private JTextField whoTxt = new JTextField(50);
	private JLabel whatLabel = new JLabel("What was the patients problem? ");
	private JTextField whatTxt = new JTextField(50);
	private JLabel whereLabel = new JLabel("Where did the problem happen? ");
	private JTextField whereTxt = new JTextField(50);
	private JLabel actionTakenLabel = new JLabel("What action was taken? ");
	private JTextField actionTakenTxt = new JTextField(50);
	private JLabel timeSpentOnCallLabel = new JLabel("How long was spent on the call? (HH:MM:SS)");
	private JTextField timeSpentOnCallTxt = new JTextField(50);
	{
		// Initialise the panel
				inputPanel.setLayout(new GridLayout(6,2));
				inputPanel.add(whoLabel);
				inputPanel.add(whoTxt);
				inputPanel.add(whatLabel);
				inputPanel.add(whatTxt);
				inputPanel.add(whereLabel);
				inputPanel.add(whereTxt);
				inputPanel.add(actionTakenLabel);
				inputPanel.add(actionTakenTxt);
				inputPanel.add(timeSpentOnCallLabel);
				inputPanel.add(timeSpentOnCallTxt);
	}
	
	// Next the panel with the buttons
	private JPanel buttonPanel = new JPanel();
	private JButton sendHospitalButton = new JButton("Send Call Out Information to Hospital");
	{
		// Initialise the panel
		buttonPanel.setLayout(new GridLayout(3, 1));
		buttonPanel.add(sendHospitalButton);
	}
	
	private JPanel topPanel = new JPanel();
	{
		topPanel.setLayout(new FlowLayout());
		topPanel.add(inputPanel);
		topPanel.add(buttonPanel);
	}
	
	// Create the panel which will display the feedback text
	private JPanel feedbackPanel = new JPanel();
	private JTextArea feedbackArea = new JTextArea(10, 40);
	JScrollPane scroller = new JScrollPane(feedbackArea);
	{
		feedbackArea.setEditable(false);
		feedbackPanel.setLayout(new GridLayout(1, 1));
		scroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		feedbackPanel.add(scroller);
	}
	
	// Finally create the window to display the panels
	private JFrame window = new JFrame("Ambulance");
	{
		window.setLayout(new GridLayout(2, 1));
		window.add(topPanel);
		window.add(feedbackPanel);
		window.pack();
	}
	//the Database connection layer that the interface will communicate with	
	private HospitalGUI Hgui;
	
	//initialise Ambulance interface
	public AmbulanceGUI()
	{
		//list action listeners
		sendHospitalButton.addActionListener(new sendHospitalListener());
		
		//set default close
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setVisible(true);
		
		//set welcome message
		feedbackArea.setText("Welcome to your ambulance PDA");	
	}
	
	private class sendHospitalListener implements ActionListener
	{
		public void actionPerformed(ActionEvent arg0) 
		{
			//send the call out information back to the ambulance
			Hgui.setMessage("Call out information update:"
					+ "\nWho? " + whoTxt.getText()
					+ "\nWhat? " + whatTxt.getText()
					+ "\nWhere? " + whereTxt.getText()
					+ "\nAction Taken: " + actionTakenTxt.getText()
					+ "\nTime Spent On Call: " + timeSpentOnCallTxt.getText());
			
			whoTxt.setText("");
			whatTxt.setText("");
			whereTxt.setText("");
			actionTakenTxt.setText("");
			timeSpentOnCallTxt.setText("");
		}
	}
	
	public void setHospital(HospitalGUI Hgui)
	{
		this.Hgui = Hgui;
	}
	
	public void setMessage(String message)
	{
		feedbackArea.setText(message);
	}
	
	
}
