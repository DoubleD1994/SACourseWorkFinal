
public class KwikMedical 
{

	public static void main(String[] args) 
	{
		DBConnection dbc = new DBConnection();
		HeadOfficeGUI HOgui = new HeadOfficeGUI(dbc);
		AmbulanceGUI Agui = new AmbulanceGUI();
		HospitalGUI Hgui = new HospitalGUI(dbc);
		
		
		Hgui.setAmbulance(Agui);
		Agui.setHospital(Hgui);
		HOgui.setAmbulanceGUI(Agui);
		HOgui.setHospitalGUI(Hgui);
		
		
	}

}
