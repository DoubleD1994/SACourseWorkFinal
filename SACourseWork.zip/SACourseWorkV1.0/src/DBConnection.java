import java.sql.*;
import java.util.ArrayList;


public class DBConnection 
{
	//Insert a new patient to the patients table
	public String InsertPatient(String NHSNumber, String name, String houseNameNumber, String street, String cityTown, String postCode, String medCondition)
	{
		try
		{
			// Load the driver
			Class.forName("com.mysql.jdbc.Driver");
			// First we need to establish a connection to the database
			Connection conn = DriverManager
					.getConnection("jdbc:mysql://localhost/kwikmedical?user=Java&password=Java");
			// Create a new SQL statement
			Statement statement = conn.createStatement();
			// Build the INSERT statement
			String update = "INSERT INTO patients (Name, HouseNameOrNumber, Street, CityOrTown, Postcode, MedicalCondition) " +
							"VALUES ('" + name + "', '" + houseNameNumber + "', '" + street + "', '" + cityTown + "', '" + postCode +"', '" + medCondition + "')";
			// Execute the statement
			statement.executeUpdate(update);
			// Release resources held by the statement
			statement.close();
			// Release resources held by the connection.  This also ensures that the INSERT completes
			conn.close();
			return "Update successful";
		}
		catch (ClassNotFoundException cnf)
		{
			return "Could not load driver " + cnf.getMessage();
		}
		catch (SQLException sqe)
		{
			return "Error performing SQL Update " + sqe.getMessage();
		}
	}
	//Find a patient based on their NHS Registration Number
	public String QueryPatients(String NHSNumber)
	{
		try 
		{
			// Load the driver
			Class.forName("com.mysql.jdbc.Driver");
			// First we need to establish a connection to the database
			Connection conn = DriverManager
					.getConnection("jdbc:mysql://localhost/kwikmedical?user=Java&password=Java");
			// Create statement object. We need to traverse results so allow
			// scrolling
			Statement statement = conn
					.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
							ResultSet.CONCUR_UPDATABLE);
			// Create query string
			String query = "SELECT * FROM patients WHERE NHSRegistrationNumber = '"
					+ NHSNumber + "'";
			// Get results from query
			ResultSet results = statement.executeQuery(query);
			// Check if we have results
			String feedback = null;
			if (results.next()) {
				// We will pull the first hit (there should be only one)
				results.first();
				String name= results.getString("Name");
				String houseNameNumber = results.getString("HouseNameOrNumber");
				String street = results.getString("Street");
				String cityTown = results.getString("CityOrTown");
				String postcode = results.getString("Postcode");
				String medicalCondition = results.getString("MedicalCondition");
				
				feedback = "NHS Registration Number - " + NHSNumber +
						"\nPatients Name - " + name +
						"\nPatients Address: \n" + houseNameNumber + " " + street +
						"\n" + cityTown +
						"\n" + postcode +
						"\n\nMedical Condition:\n" + medicalCondition;
			} 
			else 
			{
				// No matching records. Display message
				feedback = "Patient Not Found";
			}
			// Free statement resources
			statement.close();
			// Free connection resources and commit updates
			conn.close();
			return feedback;
		} 
		catch (ClassNotFoundException cnf) 
		{
			return "Could not load driver " + cnf.getMessage();
		} 
		catch (SQLException sqe) 
		{
			return "Error in SQL Update " + sqe.getMessage();
		}
	}
	//Find a patients based on their name
	public ArrayList<String> QueryPatientsName(String name)
	{
		ArrayList<String> patients= new ArrayList<String>();
		try 
		{
			// Load the driver
			Class.forName("com.mysql.jdbc.Driver");
			// First we need to establish a connection to the database
			Connection conn = DriverManager
					.getConnection("jdbc:mysql://localhost/kwikmedical?user=Java&password=Java");
			// Create statement object. We need to traverse results so allow
			// scrolling
			Statement statement = conn
					.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
							ResultSet.CONCUR_UPDATABLE);
			// Create query string
			String query = "SELECT * FROM patients WHERE Name = '"
					+ name + "'";
			// Get results from query
			ResultSet results = statement.executeQuery(query);
			// Check if we have results
			String feedback = null;
			
			int i = 0;
			//Loop through he patients that the name matches, since it is possible for more than one person to have the same name
			while(results.next()) {
				i=1;
				
				String NHSNumber= results.getString("NHSRegistrationNumber");
				String houseNameNumber = results.getString("HouseNameOrNumber");
				String street = results.getString("Street");
				String cityTown = results.getString("CityOrTown");
				String postcode = results.getString("Postcode");
				String medicalCondition = results.getString("MedicalCondition");
				
				feedback = "NHS Registration Number - " + NHSNumber +
						"\nPatients Name - " + name +
						"\nPatients Address: \n" + houseNameNumber + " " + street +
						"\n" + cityTown +
						"\n" + postcode +
						"\n\nMedical Condition:\n" + medicalCondition + "\n\n";
				patients.add(feedback);
			} 
			if(i==0) 
			{
				// No matching records. Display message
				feedback = "Patient Not Found";
				patients.add(feedback);
			}
			// Free statement resources
			statement.close();
			// Free connection resources and commit updates
			conn.close();
			return patients;
		} 
		catch (ClassNotFoundException cnf) 
		{
			String feedback = "Could not load driver " + cnf.getMessage();
			patients.add(feedback);
			return patients;
		} 
		catch (SQLException sqe) 
		{
			String feedback = "Error in SQL Update " + sqe.getMessage();
			patients.add(feedback);
			return patients;
		}
	}
	//Update a patients Information
	//Update a patients information
	public String UpdatePatientInfo(String nhsNumber, String name, String houseNameNumber, String street, String cityTown, String postCode, String medCondition)
	{
		try 
		{
			// Load the driver
			Class.forName("com.mysql.jdbc.Driver");
			// First we need to establish a connection to the database
			Connection conn = DriverManager
					.getConnection("jdbc:mysql://localhost/kwikmedical?user=Java&password=Java");
			// Create statement object. We need to traverse results so allow
			// scrolling
			Statement statement = conn
					.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
							ResultSet.CONCUR_UPDATABLE);
			// Create query string
			String query = "SELECT * FROM patients WHERE NHSRegistrationNumber = '"
					+ nhsNumber + "'";
			// Get results from query
			ResultSet results = statement.executeQuery(query);
			
			String feedback = null;
			// Check if we have results
			if (results.next()) {
				// We will pull the first hit (there should be only one)
				results.first();
				// Update the row in the DB
				results.updateString("Name", name);
				results.updateString("HouseNameOrNumber", houseNameNumber);
				results.updateString("Street", street);
				results.updateString("CityOrTown", cityTown);
				results.updateString("Postcode", postCode);
				results.updateString("MedicalCondition", medCondition);
				
				results.updateRow();
				feedback = "Record updated";
			} 
			else 
			{
				// No matching records. Display message
				feedback = "Record does not exist";
			}
			
			// Free statement resources
			statement.close();
			// Free connection resources and commit updates
			conn.close();
			
			return feedback;
		} 
		catch (ClassNotFoundException cnf) 
		{
			return "Could not load driver " + cnf.getMessage();
		} 
		catch (SQLException sqe) 
		{
			return "Error in SQL Update " + sqe.getMessage();
		}
	}
	//Insert a new call out
	//insert a new call out record
	public String InsertNewCallOut(String who, String what, String where, String actionTaken, String timeSpentOnCall)
	{
		try
		{
			// Load the driver
			Class.forName("com.mysql.jdbc.Driver");
			// First we need to establish a connection to the database
			Connection conn = DriverManager
					.getConnection("jdbc:mysql://localhost/kwikmedical?user=Java&password=Java");
			// Create a new SQL statement
			Statement statement = conn.createStatement();
			// Build the INSERT statement
			String update = "INSERT INTO call_out_information (PatientID, What, `Where`, ActionTaken, TimeSpentOnCall) " +
							"VALUES ('" + who + "', '" + what + "', '" + where + "', '" + actionTaken + "', '" + timeSpentOnCall + "')";
			// Execute the statement
			statement.executeUpdate(update);
			// Release resources held by the statement
			statement.close();
			// Release resources held by the connection.  This also ensures that the INSERT completes
			conn.close();
			return "Update successful";
		}
		catch (ClassNotFoundException cnf)
		{
			return "Could not load driver " + cnf.getMessage();
		}
		catch (SQLException sqe)
		{
			return "Error performing SQL Update " + sqe.getMessage();
		}
	}
	//Find the patients call out history
	public ArrayList<String> QueryPatientHistory(String patientID)
	{
		String feedback;
		ArrayList<String> patientHistory = new ArrayList<String>();
		try
		{
			// Load the driver
			Class.forName("com.mysql.jdbc.Driver");
			// First we need to establish a connection to the database
			Connection conn = DriverManager
					.getConnection("jdbc:mysql://localhost/kwikmedical?user=Java&password=Java");
			// Create statement object. We need to traverse results so allow
			// scrolling
			Statement statement = conn
					.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
							ResultSet.CONCUR_UPDATABLE);
			// Create query string
			String query = "SELECT * FROM call_out_information WHERE PatientID = '"
					+ patientID + "'";
			
			// Get results from query
			ResultSet results = statement.executeQuery(query);
						
			int i = 0;
			// Check if we have results and loop through all for the patient
			while (results.next()) 
			{
					i=1;
					String callOutId = results.getString("CallOutId");
					String what = results.getString("What");
					String when = results.getString("When");
					String where = results.getString("Where");
					String actionTaken = results.getString("ActionTaken");
					
					feedback = "Call Out Id - " + callOutId +
							"\npatientID - " + patientID +
							"\nWhat - \n" + what +
							"\nWhen - " + when +
							"\nWhere - " + where +
							"\nActionTaken - " + actionTaken + "\n\n";
					
					patientHistory.add(feedback);		
			}
			if (i==0)
			{
				feedback = "Record does not exist";
				patientHistory.add(feedback);
			}

						
			// Free statement resources
			statement.close();
			// Free connection resources and commit updates
			conn.close();
			
			return patientHistory;
		}
		catch (ClassNotFoundException cnf) 
		{
			feedback = "Could not load driver " + cnf.getMessage();
			patientHistory.add(feedback);
			return patientHistory;
		} 
		catch (SQLException sqe) 
		{
			feedback = "Error in SQL Update " + sqe.getMessage();
			patientHistory.add(feedback);
			return patientHistory;
		}
		
	}

}
