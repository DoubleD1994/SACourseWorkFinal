import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;

public class HeadOfficeGUI 
{
	// First set up the panel with the labels and text boxes
	private JPanel inputPanel = new JPanel();
	private JLabel nhsNumberLabel = new JLabel("NHS Registration Number: ");
	private JTextField nhsNumberTxt = new JTextField(8);
	private JLabel nameLabel = new JLabel("Name: ");
	private JTextField nameTxt = new JTextField(50);
	private JLabel houseNameNumberLabel = new JLabel("House Name Or Number: (If emergency, update later)");
	private JTextField houseNameNumberTxt = new JTextField(50);
	private JLabel streetLabel = new JLabel("Street: (If emergency, update later)");
	private JTextField streetTxt = new JTextField(50);
	private JLabel cityTownLabel = new JLabel("City Or Town: (If emergency, update later)");
	private JTextField cityTownTxt = new JTextField(50);
	private JLabel postcodeLabel = new JLabel("Postcode: (If emergency, update later) ");
	private JTextField postcodeTxt = new JTextField(9);
	private JLabel medConditionLabel = new JLabel("Medical Condition: ");
	private JTextField medConditionTxt = new JTextField(50);
	private JLabel locationLabel = new JLabel("Accident Location: ");
	private JTextField locationTxt = new JTextField(50);
	{
		// Initialise the panel
				inputPanel.setLayout(new GridLayout(8,2));
				inputPanel.add(nhsNumberLabel);
				inputPanel.add(nhsNumberTxt);
				inputPanel.add(nameLabel);
				inputPanel.add(nameTxt);
				inputPanel.add(houseNameNumberLabel);
				inputPanel.add(houseNameNumberTxt);
				inputPanel.add(streetLabel);
				inputPanel.add(streetTxt);
				inputPanel.add(cityTownLabel);
				inputPanel.add(cityTownTxt);
				inputPanel.add(postcodeLabel);
				inputPanel.add(postcodeTxt);
				inputPanel.add(medConditionLabel);
				inputPanel.add(medConditionTxt);
				inputPanel.add(locationLabel);
				inputPanel.add(locationTxt);
	}
	
	// Next the panel with the buttons
	private JPanel buttonPanel = new JPanel();
	private JButton addButton = new JButton("Add Patient");
	private JButton getButton = new JButton("Get Patient");
	private JButton updateButton = new JButton("Update Patient");
	private JButton sendAmbulanceButton = new JButton("Send Ambulance Request");
	{
		// Initialise the panel
		buttonPanel.setLayout(new GridLayout(4, 1));
		buttonPanel.add(addButton);
		buttonPanel.add(getButton);
		buttonPanel.add(updateButton);
		buttonPanel.add(sendAmbulanceButton);
	}
	
	// Now create a panel with the input and button panels in.  This is the top panel
	private JPanel topPanel = new JPanel();
	{
		topPanel.setLayout(new FlowLayout());
		topPanel.add(inputPanel);
		topPanel.add(buttonPanel);
	}
	
	// Create the panel which will display the feedback text
	private JPanel feedbackPanel = new JPanel();
	private JTextArea feedbackArea = new JTextArea(10, 40);
	JScrollPane scroller = new JScrollPane(feedbackArea);
	{
		feedbackArea.setEditable(false);
		feedbackPanel.setLayout(new GridLayout(1, 1));
		scroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		feedbackPanel.add(scroller);
	}
	
	// Finally create the window to display the panels
	private JFrame window = new JFrame("Head Office");
	{
		window.setLayout(new GridLayout(2, 1));
		window.add(topPanel);
		window.add(feedbackPanel);
		window.pack();
	}
	
	
	//the Database connection layer that the interface will communicate with
	private DBConnection dbc;
	private AmbulanceGUI Agui;
	private HospitalGUI Hgui;
	
	//initialise head office interface
	public HeadOfficeGUI(DBConnection dbc)
	{
		this.dbc = dbc;
		
		// Add your custom action listeners here
		addButton.addActionListener(new addButtonListener());
		getButton.addActionListener(new getButtonListener());
		updateButton.addActionListener(new updateButtonListener());
		sendAmbulanceButton.addActionListener(new sendAmbulanceListener());
		// The default close action
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setVisible(true);
	}
	
	
	private class getButtonListener implements ActionListener
	{
		
		public void actionPerformed(ActionEvent arg0) 
		{
			//Query database based on value of name field
			ArrayList<String> patients = new ArrayList<String>();
			patients= dbc.QueryPatientsName(nameTxt.getText());
			feedbackArea.setText(patients.toString());
		}
	}
	
	private class addButtonListener implements ActionListener
	{

		public void actionPerformed(ActionEvent arg0) 
		{
			//give information from text fields to add new patient
			feedbackArea.setText(dbc.InsertPatient(nhsNumberTxt.getText(), nameTxt.getText(), houseNameNumberTxt.getText(), streetTxt.getText(), 
					cityTownTxt.getText(), postcodeTxt.getText(), medConditionTxt.getText()));
			
			//clear fields so that ready for next input
			nhsNumberTxt.setText("");
			houseNameNumberTxt.setText("");
			streetTxt.setText("");
			cityTownTxt.setText("");
			postcodeTxt.setText("");
			medConditionTxt.setText("");
			
		}
	}
	
	private class updateButtonListener implements ActionListener
	{
		public void actionPerformed(ActionEvent arg0) 
		{
			
			//give information from text fields to update patient info
			feedbackArea.setText(dbc.UpdatePatientInfo(nhsNumberTxt.getText(), nameTxt.getText(), houseNameNumberTxt.getText(), streetTxt.getText(), 
					cityTownTxt.getText(), postcodeTxt.getText(), medConditionTxt.getText()));
			
			//clear fields so that ready for next input
			houseNameNumberTxt.setText("");
			streetTxt.setText("");
			cityTownTxt.setText("");
			postcodeTxt.setText("");
			medConditionTxt.setText("");
		}
	}
	
	private class sendAmbulanceListener implements ActionListener
	{
		public void actionPerformed(ActionEvent arg0) 
		{
			//send alert the hospital of call out. pass destination of call out and pass the patients information
			Hgui.setMessage("ALERT!\nAn ambulance has been sent to: " + locationTxt.getText() + "\nFor patient wiht NHS Number:\n" + dbc.QueryPatients(nhsNumberTxt.getText()));			
			
			//tell ambulance destination for call out. hospital sends rest of information
			Agui.setMessage("ALERT!\nPlease go to Location: " + locationTxt.getText() + ". The hospital will send through patients records.");
			
			
		}
	}
	
	public void setAmbulanceGUI(AmbulanceGUI Agui)
	{
		this.Agui = Agui;
	}
	
	public void setHospitalGUI(HospitalGUI Hgui)
	{
		this.Hgui = Hgui;
	}
}
