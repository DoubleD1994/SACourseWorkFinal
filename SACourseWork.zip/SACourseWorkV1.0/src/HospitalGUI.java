import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;

public class HospitalGUI 
{
	// First set up the panel with the labels and text boxes
		private JPanel inputPanel = new JPanel();
		private JLabel whoLabel = new JLabel("NHS Number: ");
		private JTextField whoTxt = new JTextField(50);
		private JLabel whatLabel = new JLabel("What was the patients problem? ");
		private JTextField whatTxt = new JTextField(50);
		private JLabel whereLabel = new JLabel("Where did the problem happen? ");
		private JTextField whereTxt = new JTextField(50);
		private JLabel actionTakenLabel = new JLabel("What action was taken? ");
		private JTextField actionTakenTxt = new JTextField(50);
		private JLabel timeSpentOnCallLabel = new JLabel("How long was spent on the call? (HH:MM:SS)");
		private JTextField timeSpentOnCallTxt = new JTextField(50);
		private JLabel nameLabel = new JLabel("Get patients information (Find using NHS Registration Number)");
		private JTextField nameTxt = new JTextField(50);
		private JLabel locationLabel = new JLabel("Where is the ambulance to go?");
		private JTextField locationTxt = new JTextField(50);
		{
			// Initialise the panel
			inputPanel.setLayout(new GridLayout(7,2));
			inputPanel.add(nameLabel);
			inputPanel.add(nameTxt);
			inputPanel.add(locationLabel);
			inputPanel.add(locationTxt);
			inputPanel.add(whoLabel);
			inputPanel.add(whoTxt);
			inputPanel.add(whatLabel);
			inputPanel.add(whatTxt);
			inputPanel.add(whereLabel);
			inputPanel.add(whereTxt);
			inputPanel.add(actionTakenLabel);
			inputPanel.add(actionTakenTxt);
			inputPanel.add(timeSpentOnCallLabel);
			inputPanel.add(timeSpentOnCallTxt);
		}
		
		// Next the panel with the buttons
		private JPanel buttonPanel = new JPanel();
		private JButton insertCallOutButton = new JButton("Insert Call Out Information");
		private JButton getButton = new JButton("Get Patient Information");
		private JButton sendAmbulanceInfo = new JButton("Get Patient Information and Send to Ambulance");
		{
			// Initialise the panel
			buttonPanel.setLayout(new GridLayout(3, 1));
			buttonPanel.add(sendAmbulanceInfo);
			buttonPanel.add(insertCallOutButton);
			buttonPanel.add(getButton);
		}
		
		// Now create a panel with the input and button panels in.  This is the top panel
		private JPanel topPanel = new JPanel();
		{
			topPanel.setLayout(new FlowLayout());
			topPanel.add(inputPanel);
			topPanel.add(buttonPanel);
		}
		
		// Create the panel which will display the feedback text
		private JPanel feedbackPanel = new JPanel();
		private JTextArea feedbackArea = new JTextArea(10, 40);
		JScrollPane scroller = new JScrollPane(feedbackArea);
		{
			feedbackArea.setEditable(false);
			feedbackPanel.setLayout(new GridLayout(1, 1));
			scroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
			feedbackPanel.add(scroller);
		}
		
		// Finally create the window to display the panels
		private JFrame window = new JFrame("Hospital");
		{
			window.setLayout(new GridLayout(2, 1));
			window.add(topPanel);
			window.add(feedbackPanel);
			window.pack();
		}
		
		//the Database connection layer that the interface will communicate with
		private DBConnection dbc;
		private AmbulanceGUI Agui;
		
		//initialise hospital interface
		public HospitalGUI(DBConnection dbc)
		{
			
			this.dbc = dbc;
			
			// Add your custom action listeners here
			getButton.addActionListener(new getButtonListener());
			insertCallOutButton.addActionListener(new insertCallOutButtonListener());
			sendAmbulanceInfo.addActionListener(new ambulanceInfoListener());
			// The default close action
			window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			window.setVisible(true);
		}
		
		private class getButtonListener implements ActionListener
		{
			
			public void actionPerformed(ActionEvent arg0) 
			{
				//get all the hits of people with the given name and display it
				ArrayList<String> patientHistory = new ArrayList<String>();
				patientHistory = dbc.QueryPatientHistory(nameTxt.getText());
				
				feedbackArea.setText(dbc.QueryPatients(nameTxt.getText()) + "\n\n" + patientHistory.toString());
				
				
			}
		}
		
		private class insertCallOutButtonListener implements ActionListener
		{
			
			public void actionPerformed(ActionEvent arg0) 
			{
				//Query database based on value of name field
				feedbackArea.setText(dbc.InsertNewCallOut(whoTxt.getText(), whatTxt.getText(), whereTxt.getText(), actionTakenTxt.getText(), timeSpentOnCallTxt.getText()));
				
			}
		}

		private class ambulanceInfoListener implements ActionListener
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				//get all of the patients past call outs and store in an array list to then display
				ArrayList<String> patientHistory = new ArrayList<String>();
				patientHistory = dbc.QueryPatientHistory(nameTxt.getText());
				
				//pass the information onto the ambulance
				Agui.setMessage("ALERT!\nPlease go to Location: " + locationTxt.getText() 
						+"\n\nPatitents Information: "+ dbc.QueryPatients(nameTxt.getText())
						+"\n\nPatients past call outs:\n"+ patientHistory.toString());
				
				//set the hospitals feedback area to the searched patients information and the patients past call out information
				feedbackArea.setText("Patitents Information: "+ dbc.QueryPatients(nameTxt.getText())
						+"\n\nPatients past call outs:\n"+ patientHistory.toString());
				
			}
		}
		
		public void setAmbulance(AmbulanceGUI Agui)
		{
			this.Agui = Agui;
		}
		
		public void setMessage(String message)
		{
			feedbackArea.setText(message);
		}
}
